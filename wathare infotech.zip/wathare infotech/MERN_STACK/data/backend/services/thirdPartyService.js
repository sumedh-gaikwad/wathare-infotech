// services/thirdPartyService.js

const axios = require('axios');

// Service functions for integrating with third-party APIs

// Function to fetch location-based temperature data from a third-party API
const fetchTemperatureData = async (location) => {
  try {
    // Make a GET request to the third-party API to fetch temperature data for the provided location
    const response = await axios.get(`https://example.com/api/temperature?location=${location}`);
    
    // Return the temperature data from the response
    return response.data;
  } catch (error) {
    // Handle errors if the API request fails
    console.error('Error fetching temperature data:', error);
    throw new Error('Failed to fetch temperature data');
  }
};

module.exports = {
  fetchTemperatureData,
};
