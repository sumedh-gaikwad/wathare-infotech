// models/Data.js

const mongoose = require('mongoose');

const dataSchema = new mongoose.Schema({
  timestamp: {
    type: Date,
    required: true,
  },
  sample: {
    type: Number,
    required: true,
  },
  // Add more fields as needed based on your data structure
});

module.exports = mongoose.model('Data', dataSchema);
