// Import required modules
const mongoose = require('mongoose');

// Define your MongoDB schema
const dataSchema = new mongoose.Schema({
  timestamp: {
    type: Date,
    required: true
  },
  value: {
    type: Number,
    required: true
  }
});

// Create a Mongoose model based on the schema
const Data = mongoose.model('Data', dataSchema);

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/sampledata', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
  console.log('Connected to MongoDB');
})
.catch((err) => {
  console.error('Error connecting to MongoDB:', err);
});

// Insert data into the database
const newData = new Data({
  timestamp: new Date(),
  value: 1 
});

newData.save()
.then(() => {
  console.log('Data inserted successfully');
})
.catch((err) => {
  console.error('Error inserting data:', err);
});
