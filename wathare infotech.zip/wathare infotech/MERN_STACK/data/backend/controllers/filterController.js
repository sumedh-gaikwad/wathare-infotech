// controllers/filterController.js

const Data = require('../models/Data');

// Controller functions for data filtering operations


const filterData = async (req, res) => {
  try {
    const { startTime, endTime, interval } = req.query;
    let filterQuery = {};
    
    // Construct query based on provided parameters
    if (startTime && endTime) {
      filterQuery.timestamp = { $gte: new Date(startTime), $lte: new Date(endTime) };
    }
    
    
    
    const filteredData = await Data.find(filterQuery);
    res.status(200).json({ success: true, data: filteredData });
  } catch (error) {
    console.error('Error filtering data:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

module.exports = {
  filterData,
};
