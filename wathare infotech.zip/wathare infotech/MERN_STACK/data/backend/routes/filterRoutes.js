// routes/filterRoutes.js

const express = require('express');
const router = express.Router();
const filterController = require('../controllers/filterController');

// Filter data by time interval and starting time
router.get('/', filterController.filterData);

module.exports = router;
