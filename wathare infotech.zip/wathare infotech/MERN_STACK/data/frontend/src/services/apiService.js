import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api'; // Example base URL of your backend API

const apiService = {
  getData: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/data`);
      return response.data;
    } catch (error) {
      throw new Error('Error fetching data from the API:', error);
    }
  },

  filterData: async (startTime, frequency) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/data/filter`, {
        params: { startTime, frequency }
      });
      return response.data;
    } catch (error) {
      throw new Error('Error filtering data from the API:', error);
    }
  }
};

export default apiService;
