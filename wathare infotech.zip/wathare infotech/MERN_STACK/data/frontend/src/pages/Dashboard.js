import React, { useState, useEffect } from 'react';
import DataPlot from '../components/DataPlot';
import SummaryTable from '../components/SummaryTable';
import FilterForm from '../components/FilterForm';
import apiService from '../services/apiService'; // Assuming you have an apiService for making API requests

const Dashboard = () => {
  // Sample data (replace with actual data fetched from the backend)
  const [data, setData] = useState([]);

  // Fetch data from the backend on component mount
  useEffect(() => {
    fetchData();
  }, []);

  // Function to fetch data from the backend
  const fetchData = async () => {
    try {
      const response = await apiService.getData(); // Example: apiService.getData() fetches data from backend API
      setData(response.data); // Assuming response.data contains the fetched data
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <div>
      <h1>Dashboard</h1>
      <FilterForm fetchData={fetchData} /> {/* Pass fetchData function to the FilterForm component */}
      <DataPlot data={data} /> {/* Pass data to the DataPlot component */}
      <SummaryTable data={data} /> {/* Pass data to the SummaryTable component */}
    </div>
  );
};

export default Dashboard;
