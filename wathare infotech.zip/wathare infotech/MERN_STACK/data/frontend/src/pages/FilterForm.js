import React, { useState } from 'react';

const FilterForm = ({ fetchData }) => {
  const [startTime, setStartTime] = useState('');
  const [frequency, setFrequency] = useState('hour');

  const handleStartTimeChange = (e) => {
    setStartTime(e.target.value);
  };

  const handleFrequencyChange = (e) => {
    setFrequency(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform validation on startTime if needed
    // Call fetchData function with startTime and frequency parameters
    fetchData(startTime, frequency);
  };

  return (
    <div>
      <h2>Filter Data</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="startTime">Start Time:</label>
          <input
            type="datetime-local"
            id="startTime"
            value={startTime}
            onChange={handleStartTimeChange}
            required
          />
        </div>
        <div>
          <label htmlFor="frequency">Frequency:</label>
          <select id="frequency" value={frequency} onChange={handleFrequencyChange}>
            <option value="hour">Hourly</option>
            <option value="day">Daily</option>
            <option value="week">Weekly</option>
            <option value="month">Monthly</option>
          </select>
        </div>
        <button type="submit">Filter</button>
      </form>
    </div>
  );
};

export default FilterForm;
