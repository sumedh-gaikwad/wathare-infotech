import React, { useEffect, useState } from 'react';
import Chart from 'chart.js/auto';

const DataPlot = () => {
  // Sample data (replace with your actual data)
  const [data, setData] = useState([0, 1, 0, 1, null, 0, 1, 1, 0, null, 0, 0]);

  useEffect(() => {
    // Initialize the chart on component mount
    const ctx = document.getElementById('dataChart');
    const chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: data.map((_, index) => index + 1), // Use index as labels
        datasets: [{
          label: 'Data Plot',
          data: data.map(value => value === null ? NaN : value), // Handle null values as NaN
          backgroundColor: data.map(value => {
            if (value === null) return 'red'; // Red for missing data
            return value === 0 ? 'yellow' : 'green'; // Yellow for 0, green for 1
          }),
          borderColor: 'black',
          borderWidth: 1,
          fill: false
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            ticks: {
              stepSize: 1,
              callback: value => {
                if (isNaN(value)) return ''; // Hide NaN labels
                return value === 0 ? '0' : '1'; // Show 0 and 1 labels
              }
            }
          }
        }
      }
    });

    // Cleanup function
    return () => {
      chart.destroy();
    };
  }, [data]); // Re-render the chart when data changes

  return (
    <div>
      <h2>Data Plot</h2>
      <canvas id="dataChart" width="400" height="200"></canvas>
    </div>
  );
};

export default DataPlot;
